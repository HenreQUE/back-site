create database trekit;
use trekit;

create table materiais(
	codigo_material int primary key auto_increment not null,
	nome_material varchar(45) not null,
    tipo_material varchar(45) not null,
    dimensoes_material varchar(45) not null
);

create table kit(
	codigo_kit int primary key auto_increment not null,
    nome_kit varchar(45) not null,
    tipo_kit varchar(45) not null,
    dimensoes_kit varchar(45) not null
)
