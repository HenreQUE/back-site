const express = require('express');
const cors = require('cors');
//definir a porta
const porta = 3001;
const app = express();
//habilitar o cors e utilizar json
app.use(cors());
app.use(express.json());
//testar
app.listen(porta, () => console.log(`rodando na porta ` + porta));
const connection = require('./db_config');

// tem q instalar os pacotes no pc q vai apresentar


// Registro de Material

app.post('/material/registrar', (request, response) => {
    let params = Array(
        request.body.codigoMaterial,
        request.body.nomeMaterial,
        request.body.tipoMaterial,
        request.body.dimensoesMaterial
    );
 console.log("here", params)
    let query = "INSERT INTO materiais(codigo_material, nome_material, tipo_material, dimensoes_material) values(?,?,?,?);";
   
    connection.query(query, params, (err, results) => {
        if(results) {
            response
            .status(201)
            .json({
                success: true,
                message: "Sucesso",
                data: results
            })
 
        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "Sem sucesso",
                data: err
            })
        }
    })
});

// Registro de Kit

app.post('/kit/registrar', (request, response) => {
    let params = Array(
        request.body.codigoKit,
        request.body.nomeKit,
        request.body.tipoKit,
        request.body.dimensoesKit
    );
 console.log(params)
    let query = "INSERT INTO kit(codigo_kit, nome_kit, tipo_kit, dimensoes_kit) values(?,?,?,?);";
   
    connection.query(query, params, (err, results) => {
        if(results) {
            response
            .status(201)
            .json({
                success: true,
                message: "Sucesso",
                data: results
            })
 
        } else {
            response
            .status(400)
            .json({
                success: false,
                message: "Sem sucesso",
                data: err
            })
        }
    })
});

